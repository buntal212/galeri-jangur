import { c as defineEventHandler, u as useRuntimeConfig, e as setResponseHeader } from '../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue-router';
import 'node:url';
import 'node:crypto';

const xmlEscape = (value) => String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
const sitemap_xml = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig(event);
  const siteUrl = String(config.public.siteUrl || "").replace(/\/+$/, "");
  const apiBase = String(config.public.apiBase || "").replace(/\/+$/, "");
  const products = [];
  try {
    const firstResponse = await $fetch(
      `${apiBase}/product/get-products`,
      {
        query: {
          page: 1,
          per_page: 100
        }
      }
    );
    const firstPage = firstResponse == null ? void 0 : firstResponse.data;
    if (Array.isArray(firstPage == null ? void 0 : firstPage.data)) {
      products.push(...firstPage.data);
    }
    const lastPage = Number((firstPage == null ? void 0 : firstPage.last_page) || 1);
    for (let page = 2; page <= lastPage; page++) {
      const response = await $fetch(
        `${apiBase}/product/get-products`,
        {
          query: {
            page,
            per_page: 100
          }
        }
      );
      const pageProducts = ((_a = response == null ? void 0 : response.data) == null ? void 0 : _a.data) || [];
      if (Array.isArray(pageProducts)) {
        products.push(...pageProducts);
      }
    }
  } catch (error) {
    console.error("Failed generating sitemap products:", error);
  }
  const productUrls = products.map((item) => item.slug).filter(Boolean).flatMap((productSlug) => [`${siteUrl}/produk/${productSlug}`, `${siteUrl}/en/products/${productSlug}`]);
  const urls = [
    `${siteUrl}/`,
    `${siteUrl}/en`,
    `${siteUrl}/tentang`,
    `${siteUrl}/en/about`,
    `${siteUrl}/kontak`,
    `${siteUrl}/en/contact`,
    ...productUrls
  ].filter(Boolean).filter((url, index, all) => all.indexOf(url) === index);
  setResponseHeader(
    event,
    "content-type",
    "application/xml; charset=utf-8"
  );
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map((url) => `  <url><loc>${xmlEscape(url)}</loc></url>`).join("\n")}
</urlset>`;
});

export { sitemap_xml as default };
//# sourceMappingURL=sitemap.xml.mjs.map
