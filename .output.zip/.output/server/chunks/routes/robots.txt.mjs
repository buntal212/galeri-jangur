import { c as defineEventHandler, u as useRuntimeConfig, e as setResponseHeader } from '../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue-router';
import 'node:url';
import 'node:crypto';

const robots_txt = defineEventHandler((event) => {
  const config = useRuntimeConfig(event);
  const siteUrl = String(config.public.siteUrl || "https://jangur-keramik.my.id").replace(/\/+$/, "");
  setResponseHeader(event, "content-type", "text/plain; charset=utf-8");
  return `User-agent: *
Allow: /
Disallow: /login
Disallow: /admin

Sitemap: ${siteUrl}/sitemap.xml
`;
});

export { robots_txt as default };
//# sourceMappingURL=robots.txt.mjs.map
